// js/booking.js
const BOT_TOKEN = 'REPLACE_WITH_YOUR_BOT_TOKEN';
const CHAT_ID = 'REPLACE_WITH_YOUR_CHAT_ID'; // can be group or user id

document.getElementById('year').textContent = new Date().getFullYear();

function serializeBooking(form) {
  return {
    name: form.name.value.trim(),
    phone: form.phone.value.trim(),
    date: form.date.value,
    time: form.time.value,
    master: form.master.value,
    service: form.service.value,
    created: new Date().toISOString()
  };
}

async function sendToTelegram(message) {
  if (!BOT_TOKEN || !CHAT_ID || BOT_TOKEN.includes('REPLACE')) {
    throw new Error('BOT_TOKEN or CHAT_ID not set');
  }
  const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;
  const body = {
    chat_id: CHAT_ID,
    parse_mode: 'HTML',
    text: message
  };
  const res = await fetch(url, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(body) });
  return res.ok;
}

function formatMessage(data, queueNumber) {
  return `<b>Новая запись — Barber PRESTIGE</b>%0A` +
         `Имя: ${data.name}%0AТелефон: ${data.phone}%0AДата: ${data.date} ${data.time}%0AМастер: ${data.master}%0AУслуга: ${data.service}%0AНомер в очереди: ${queueNumber}%0AВремя: ${data.created}`;
}

document.getElementById('bookingForm').addEventListener('submit', async function(e){
  e.preventDefault();
  const form = e.target;
  const data = serializeBooking(form);
  // save to local queue first
  const queue = JSON.parse(localStorage.getItem('bookingQueue') || '[]');
  queue.push(data);
  localStorage.setItem('bookingQueue', JSON.stringify(queue));
  const queueNumber = queue.length;
  const message = formatMessage(data, queueNumber);
  let sent = false;
  try {
    sent = await sendToTelegram(message);
  } catch(err){
    console.warn('Telegram send failed:', err);
    sent = false;
  }
  if(sent){
    alert('Запись отправлена в Telegram. Номер в очереди: ' + queueNumber);
  } else {
    alert('Запись сохранена локально. Номер в очереди: ' + queueNumber + '. Настройте BOT_TOKEN и CHAT_ID для отправки в Telegram.');
  }
  form.reset();
});

document.getElementById('viewQueue').addEventListener('click', function(){
  const queue = JSON.parse(localStorage.getItem('bookingQueue') || '[]');
  const panel = document.getElementById('queuePanel');
  if(queue.length===0){ panel.textContent = 'Очередь пуста.'; return; }
  panel.innerHTML = '<strong>Текущая очередь:</strong><ol>' + queue.map(q=>`<li>${q.date} ${q.time} — ${q.name} (${q.service})</li>`).join('') + '</ol>';
});

// expose helpers for easy testing
window.__BarberPrestige = {
  getQueue: ()=> JSON.parse(localStorage.getItem('bookingQueue')||'[]'),
  clearQueue: ()=> localStorage.removeItem('bookingQueue')
};
